package mdsky.applications.blockchain;
import java.security.KeyPair;
import java.security.PublicKey;
import java.util.ArrayList;
public class TestTransaction {
	public static void main(String[] args) 
	{
		//generate the sender
		KeyPair sender = UtilityMethods.generateKeyPair();
		//let's have two receivers
		PublicKey[] receivers = new PublicKey[2];
		double[] fundsToTransfer = new double[receivers.length];
		for(int i=0; i<receivers.length; i++){
			receivers[i] = UtilityMethods.generateKeyPair().getPublic();
			fundsToTransfer[i] = (i+1) * 100;
		}
		//as we do not have a Wallet class to make the transaction, we need to manually create
		//the input UTXOs and output UTXO
		UTXO uin = new UTXO("0", sender.getPublic(), sender.getPublic(), 1000);
		ArrayList<UTXO> input = new ArrayList<UTXO>();
		input.add(uin);
		Transaction T = new Transaction(sender.getPublic(), receivers, fundsToTransfer, input);
		//make sure that the sender has enough fund
		double available = 0.0;
		for(int i=0; i<input.size(); i++){
			available += input.get(i).getFundTransferred();
		}
		//compute the total cost, add the transaction fee
		double totalCost = T.getTotalFundToTransfer() + Transaction.TRANSACTION_FEE;
		//if fund is not enough, abort
		if(available < totalCost){
			System.out.println("fund available="+available+", not enough for total cost of "+totalCost);
			return;
		}
		
		boolean b = T.prepareOutputUTXOs();	
		if(!b){
			System.out.println("Transaction failed");
		}else{
			T.signTheTransaction(sender.getPrivate());
			//display the transaction to take a look
			UtilityMethods.displayTransaction(T, System.out, 1);
		}
	}


}

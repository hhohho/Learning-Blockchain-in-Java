package mdsky.applications.blockchain;

public class TestXOR {

	public static void main(String[] args) {
		String message = "At the most beautiful place, remember the most beautiful you.";
		String password = "blockchains";
		byte[] encrypted = UtilityMethods.encryptionByXOR(message.getBytes(), password);
		//take a peek at the encrypted data
		System.out.println(new String(encrypted));
		byte[] decrypted = UtilityMethods.decryptionByXOR(encrypted, password);
		//examine the decrypted message
		System.out.println("after proper decryption, the message is:\n");
		System.out.println(new String(decrypted));
		//let's try an incorrect password
		System.out.println("\nwith an incorrect password, the decrpted message looks like:");
		decrypted = UtilityMethods.decryptionByXOR(encrypted, "Block Chain");
		//exmaine the wrongly decrypted message
		System.out.println(new String(decrypted));
	}

}

package mdsky.applications.blockchain;

public class Miner extends Wallet
{
	public Miner(String minerName, String password) 
	{
		super(minerName, password);
	}
	
	public Miner(String minerName)
	{ 
		super(minerName);
	}
	
	public boolean mineBlock(Block block)
	{
		return (block.mineTheBlock());
	} 
}

package mdsky.applications.blockchain;

public class TestEncryptionDecryptionWithAES {

	public static void main(String[] args) {
		String message = "At the most beautiful place, remember the most beautiful you.";
		String password = "blockchains";
		byte[] encrypted = UtilityMethods.encryptionByAES(message.getBytes(), password);
		//take a peek at the encrypted data
		System.out.println(new String(encrypted));
		byte[] decrypted = UtilityMethods.decryptionByAES(encrypted, password);
		//examine the decrypted message
		System.out.println("The encrypted message below is not readable");
		System.out.println(new String(decrypted));
		//let's try an incorrect password
		try{
			System.out.println("When using an incorrect password");
			decrypted = UtilityMethods.decryptionByAES(encrypted, "Block Chain");
			//exmaine the wrongly decrypted message
			System.out.println(new String(decrypted));
		}catch(Exception e){
			System.out.println("Runtime exception happened. Cannot work");
		}
	}

}
